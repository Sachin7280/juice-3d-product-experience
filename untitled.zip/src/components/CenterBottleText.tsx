import { motion, AnimatePresence } from "motion/react";

export default function CenterBottleText({ activeFlavor }: { activeFlavor: any }) {
  return (
    <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none mix-blend-overlay text-white font-display text-center select-none pt-12 md:pt-24 scale-90 md:scale-100 drop-shadow-2xl opacity-90">
           {/* Animated Flavor Name */}
           <div className="h-12 mb-2 overflow-hidden w-full flex justify-center">
             <AnimatePresence mode="popLayout">
               <motion.div 
                 key={activeFlavor.id}
                 initial={{ y: 30, opacity: 0 }}
                 animate={{ y: 0, opacity: 1 }}
                 exit={{ y: -30, opacity: 0 }}
                 transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
                 className="text-[18px] md:text-[20px] font-bold tracking-[0.2em] whitespace-pre-line leading-tight uppercase"
               >
                 {activeFlavor.name}
               </motion.div>
             </AnimatePresence>
           </div>
           
           {/* Static Logo on label */}
           <h2 className="text-[2.2rem] md:text-[2.8rem] font-bold leading-[0.9] tracking-tight mb-4 flex flex-col">
             <span>CHROMA</span>
             <span className="text-[1.9rem] md:text-[2.4rem]">JUICE</span>
           </h2>
           
           {/* Tagline */}
           <p className="text-[10px] md:text-[12px] uppercase tracking-[0.3em] font-sans mt-[160px] md:mt-[220px] drop-shadow-lg font-bold">
             Taste The Colors Of India
           </p>
    </div>
  );
}
