export default function FlavorCard({ activeFlavor, onBuyClick }: { activeFlavor: any, onBuyClick: () => void }) {
  return (
    <div className="bg-black/30 backdrop-blur-xl border border-white/20 rounded-[32px] p-5 pr-6 flex items-center gap-6 shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden w-full max-w-[300px]">
      {/* Miniature bottle thumbnail */}
      <div className="w-[60px] h-[100px] bg-white/10 rounded-[20px] flex-shrink-0 flex items-center justify-center relative shadow-inner overflow-hidden border border-white/10">
         <div
           className="absolute inset-x-0 bottom-0 top-5"
           style={{ backgroundColor: activeFlavor.themeColor }}
         />
         {/* Mini cap */}
         <div className="absolute top-2 w-[24px] h-[8px] bg-white/40 rounded-full" />
         <div className="absolute top-4 w-[16px] h-[4px] bg-white/30 rounded-full" />
         {/* Mini glass shine */}
         <div className="absolute left-2.5 top-8 bottom-4 w-[3px] bg-white/40 rounded-full blur-[0.5px]" />
      </div>

      <div className="flex flex-col flex-1 w-full relative z-10">
        <span className="text-[10px] uppercase tracking-[0.2em] text-white/80 font-bold mb-1 drop-shadow-md">Smoothie</span>
        
        <div className="h-[22px] relative overflow-hidden mb-4">
          <div className="absolute inset-0 font-display font-bold text-[15px] tracking-wide whitespace-nowrap drop-shadow-md">
            {activeFlavor.shortName}
          </div>
        </div>

        <button 
          onClick={onBuyClick}
          className="w-full py-2.5 rounded-full font-bold text-[14px] shadow-lg transition-all flex justify-center items-center h-10 hover:scale-[1.05] active:scale-[0.95] cursor-pointer"
          style={{ backgroundColor: activeFlavor.themeColor, color: '#ffffff', textShadow: "0 1px 2px rgba(0,0,0,0.4)" }}
        >
          Buy
        </button>
      </div>
    </div>
  );
}
