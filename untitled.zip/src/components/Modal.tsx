import { X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Modal({ isOpen, title, onClose }: { isOpen: boolean, title: string, onClose: () => void }) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="bg-[#1a1a1a] border border-white/20 p-8 rounded-3xl shadow-2xl max-w-md w-full relative"
          >
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors cursor-pointer"
            >
              <X size={24} />
            </button>
            <h2 className="text-2xl font-display font-bold text-white mb-4">{title}</h2>
            <p className="text-white/80 font-sans">
              This is a demo action. In a real application, this would open the {title.toLowerCase()} flow or modal.
            </p>
            <div className="mt-8 flex justify-end">
                <button onClick={onClose} className="px-6 py-2 bg-white text-black font-semibold rounded-full hover:bg-white/90 transition-colors cursor-pointer">
                    Close
                </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
