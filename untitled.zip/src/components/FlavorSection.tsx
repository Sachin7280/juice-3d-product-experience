import { motion, useTransform, MotionValue } from "motion/react";
import MainContent from "./MainContent";
import FlavorCard from "./FlavorCard";

export default function FlavorSection({ 
  flavor, 
  index, 
  scrollYProgress, 
  isActive,
  onAction 
}: { 
  flavor: any; 
  index: number; 
  scrollYProgress: MotionValue<number>; 
  isActive: boolean;
  onAction: (title: string) => void;
}) {
  const step = 1 / 3; 
  const start = index * step;
  const end = (index + 1) * step;
  
  const fadeStart = index === 0 ? 0 : start - 0.15;
  const fullStart = index === 0 ? 0.001 : start + 0.1;
  const fullEnd = index === 2 ? 0.999 : end - 0.1;
  const fadeEnd = index === 2 ? 1 : end + 0.15;

  const opacity = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [0, 1, 1, 0]
  );
  
  const y = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [400, 0, 0, -400]
  );

  const rotateX = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [-60, 0, 0, 60] 
  );

  const scale = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [0.7, 1, 1, 0.7] 
  );

  const leftZ = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [-1000, 0, 0, -1000]
  );
  
  const rightZ = useTransform(scrollYProgress, 
    [fadeStart, fullStart, fullEnd, fadeEnd], 
    [-1000, 0, 0, -1000]
  );

  const leftRotateY = useTransform(scrollYProgress,
    [fadeStart, fullStart, fullEnd, fadeEnd],
    [-80, 0, 0, 80]
  );

  const rightRotateY = useTransform(scrollYProgress,
    [fadeStart, fullStart, fullEnd, fadeEnd],
    [80, 0, 0, -80]
  );

  return (
    <motion.div 
      style={{ 
        opacity, 
        y, 
        scale,
        rotateX, 
        transformStyle: "preserve-3d",
        pointerEvents: isActive ? "auto" : "none"
      }}
      className="absolute inset-0 grid grid-cols-12 gap-6 items-center px-6"
    >
      {/* Left Text */}
      <motion.div 
        style={{ z: leftZ, rotateY: leftRotateY, transformStyle: "preserve-3d" }}
        className="col-span-12 md:col-span-6 lg:col-span-5"
      >
        <MainContent flavor={flavor} onShopClick={() => onAction("Shop Now")} />
      </motion.div>

      {/* Right Card */}
      <motion.div 
        style={{ z: rightZ, rotateY: rightRotateY, transformStyle: "preserve-3d" }}
        className="col-span-12 md:col-span-4 md:col-start-9 flex justify-center md:justify-end items-center mt-16 md:mt-0"
      >
        <FlavorCard activeFlavor={flavor} onBuyClick={() => onAction(`Buy ${flavor.shortName}`)} />
      </motion.div>
    </motion.div>
  );
}
