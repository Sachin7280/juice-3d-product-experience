import { ShoppingBag } from "lucide-react";

export default function Navigation({ onAction }: { onAction: (title: string) => void }) {
  return (
    <nav className="w-full max-w-[1400px] mx-auto px-6 md:px-8 py-6 md:py-8 flex items-center justify-between text-white z-20 relative text-[13px] tracking-wide pointer-events-auto">
      <div className="flex items-center gap-16">
        {/* Logo */}
        <div 
          onClick={() => onAction("Home")}
          className="flex items-center gap-2 cursor-pointer transition-transform hover:scale-105 active:scale-95"
        >
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="#D3F26A"/>
              <path d="M18.36 5.64A9.96 9.96 0 0012 2C6.48 2 2 6.48 2 12c0 2.22.72 4.28 1.93 5.93C5.55 13.9 8.5 11 12 11c3.5 0 6.45 2.9 8.07 6.93A9.96 9.96 0 0022 12c0-2.37-.82-4.55-2.2-6.25l-1.44-1.44v.01l-1.44-1.44z" fill="#D3F26A"/>
            </svg>
        </div>

        {/* Links */}
        <div className="hidden lg:flex gap-10 font-medium opacity-90 text-[14px]">
          <button onClick={() => onAction("Shop")} className="hover:opacity-100 font-semibold transition-opacity cursor-pointer">Shop</button>
          <button onClick={() => onAction("Company")} className="hover:opacity-100 transition-opacity cursor-pointer">Company</button>
          <button onClick={() => onAction("Reviews")} className="hover:opacity-100 transition-opacity cursor-pointer">Reviews</button>
          <button onClick={() => onAction("Contact")} className="hover:opacity-100 transition-opacity cursor-pointer">Contact</button>
        </div>
      </div>

      <div className="flex items-center gap-8 font-medium">
        <span className="hidden sm:inline w-max opacity-90 font-semibold tracking-wider text-[14px]">+91 98765 43210</span>
        <button 
          onClick={() => onAction("Shopping Cart")}
          className="flex items-center gap-3 bg-white/10 hover:bg-white/20 transition-colors px-6 py-3 rounded-full border border-white/20 backdrop-blur-md shadow-sm cursor-pointer"
        >
          <span className="font-semibold">Cart</span>
          <ShoppingBag size={16} />
        </button>
      </div>
    </nav>
  );
}
