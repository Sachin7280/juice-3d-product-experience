import { ArrowRight } from "lucide-react";

export default function MainContent({ flavor, onShopClick }: { flavor: any, onShopClick: () => void }) {
  return (
    <div className="flex flex-col items-start gap-6 md:gap-8 z-20">
      <h1 className="text-[3.5rem] sm:text-[4.5rem] lg:text-[5.5rem] font-bold font-display leading-[0.95] tracking-[-0.02em] text-white drop-shadow-xl uppercase">
        CHROMA <br/>
        <span 
          className="py-1 block drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)]" 
          style={{ color: flavor.themeColor }}
        >
          JUICE
        </span>
      </h1>
      
      <div className="w-full max-w-[340px]">
        <p className="text-[14px] sm:text-[15px] text-white/95 leading-[1.6] font-medium font-sans drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
          {flavor.description}
        </p>
      </div>
      
      <button 
        onClick={onShopClick}
        className="mt-4 flex items-center gap-4 px-8 py-4 rounded-full cursor-pointer border border-white/40 hover:bg-white hover:text-black hover:border-white transition-all duration-300 backdrop-blur-sm group shadow-[0_8px_32px_rgba(0,0,0,0.3)] bg-black/40 hover:shadow-white/50"
      >
        <span className="font-bold text-[13px] tracking-[0.08em] uppercase">Shop Now</span>
        <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  );
}
