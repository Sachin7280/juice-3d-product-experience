/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useSpring } from "motion/react";
import Navigation from "./components/Navigation";
import Modal from "./components/Modal";
import FlavorSection from "./components/FlavorSection";
import CenterBottleText from "./components/CenterBottleText";

const FLAVORS = [
  {
    id: "pink",
    themeColor: "#935C7A", // Blush purple
    name: "POMEGRANATE\nSTRAWBERRY",
    shortName: "Pomegranate, Strawberry",
    description: "Fresh Indian Pomegranate and Strawberry transform into unique, flavorful blends. They merge together like life itself, and the color of your mood will adapt to anything."
  },
  {
    id: "orange",
    themeColor: "#D67A36", // Vibrant orange
    name: "ALPHONSO\nMANGO",
    shortName: "Alphonso Mango",
    description: "The king of Indian fruits, Alphonso Mango, gives this blend a rich, tropical sweetness that brightens your day and fills you with warm sun-kissed energy."
  },
  {
    id: "green",
    themeColor: "#5C8C56", // Leaf green
    name: "MINT\nLIME",
    shortName: "Mint, Lime",
    description: "Cool mint and zesty lime create a refreshing burst of flavor. This revitalizing blend clears your mind and cools your senses, perfect for a hot summer day."
  },
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 60,
    damping: 18,
    restDelta: 0.001
  });

  useEffect(() => {
    return smoothProgress.on("change", (v) => {
      // 3 flavors => split into 3 segments
      if (v < 0.33) setCurrentIndex(0);
      else if (v < 0.66) setCurrentIndex(1);
      else setCurrentIndex(2);
    });
  }, [smoothProgress]);

  const activeFlavor = FLAVORS[currentIndex];

  const handleAction = (title: string) => {
    setModalTitle(title);
    setIsModalOpen(true);
  };

  return (
    <div ref={containerRef} className="relative w-full h-[400vh] bg-[#0a0a0a]">
        <div className="fixed inset-0 w-full h-full flex flex-col font-sans text-white overflow-hidden bg-[#0a0a0a]">
          {/* Background Video directly from Cloudinary */}
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            className="absolute inset-0 w-full h-full object-cover z-0"
            src="https://res.cloudinary.com/djsurxemd/video/upload/v1781692223/extract_background_video_and_r_xskgih.mp4"
          />
          
          {/* Dark overlay to make text more readable against the video */}
          <div className="absolute inset-0 z-0 bg-black/20 pointer-events-none" />

          {/* Optional color tint matched to flavor */}
          <motion.div 
            className="absolute inset-0 z-0 pointer-events-none mix-blend-overlay opacity-40"
            animate={{ backgroundColor: activeFlavor.themeColor }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          
          <CenterBottleText activeFlavor={activeFlavor} />

          <Navigation onAction={handleAction} />
          
          <main className="flex-1 w-full h-full max-w-[1400px] mx-auto relative z-20 pt-8 pb-24 md:py-8 pointer-events-none flex items-center" style={{ perspective: "1500px" }}>
            {FLAVORS.map((flavor, index) => (
                <FlavorSection
                    key={flavor.id}
                    flavor={flavor}
                    index={index}
                    scrollYProgress={smoothProgress}
                    isActive={currentIndex === index}
                    onAction={handleAction}
                />
            ))}
          </main>
        </div>

        <Modal isOpen={isModalOpen} title={modalTitle} onClose={() => setIsModalOpen(false)} />

        {/* Scroll helper text */}
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-20 text-white/60 text-[11px] uppercase tracking-widest font-bold flex flex-col items-center gap-3 pointer-events-none drop-shadow-md">
            <span>Scroll To Experience</span>
            <div className="w-[2px] h-8 bg-white/20 relative overflow-hidden rounded-full">
                <motion.div 
                    className="absolute inset-x-0 top-0 h-1/2 bg-white rounded-full"
                    animate={{ y: [0, 32] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                />
            </div>
        </div>
    </div>
  );
}
